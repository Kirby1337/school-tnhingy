// Movement

let cnv = document.getElementById("canvas");
let ctx = cnv.getContext("2d");
cnv.width = 1150;
cnv.height = 700;

let player = {
 x: 200,
 y: 550,
 w: 50,
 h: 50,
 xSpeed: 5,
 ySpeed: 0,
 a: 0.5,
 col: "#0677FE"
}

let obstacle = {
  x: 400,
  y: 530,
  w: 20,
  h: 190,
}

let obstacle2 = {
  x: 400,
  y: 600,
  w: 200,
  h: 190,
}

let flyingObject = {
  x: 500,
  y: 600,
  w: 200,
  h: 100
}

let rightArrowPressed = false;
let leftArrowPressed = false;
let leftshiftPressed = false;

requestAnimationFrame(main);

function main() {

  movePlayerHz();
  movePlayerVt();
  flyingObstacle();


ctx.clearRect(0, 0, cnv.width, cnv.height);
drawPlayer();

drawObstacle();
drawObstacle2();

requestAnimationFrame(main);
}

document.addEventListener("keydown", keydownHandler);
document.addEventListener("keyup", keyupHandler);

function keydownHandler(event) {
  console.log(event.code);
  if (event.code == "ArrowRight") {
    rightArrowPressed = true;
  } else if (event.code == "ArrowLeft") {
    leftArrowPressed = true;
  } else if (event.code == "ArrowUp") {
    player.ySpeed = -15;
  } else if (event.code == "107"){
    player.xSpeed = +20;
  } else if (event.code == "ShiftLeft"){
    player.w = Math.floor((Math.random() * 50) + 200);
    player.h= Math.floor((Math.random() * 20) + 100)
    leftShiftPressed = true;
  }
}

function keyupHandler(event){
  if (event.code == "ArrowRight") {
    rightArrowPressed = false;
  } else if (event.code == "ArrowLeft"){
    leftArrowPressed = false;
  } 
}
